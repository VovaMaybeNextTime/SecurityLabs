import UIKit

let url = URL(string: "http://95.217.177.249/casino/createacc")!

let playerId = Int.random(in: 0...99_999_999)

var response = URL(string: "http://95.217.177.249/casino/createacc" + "?id=" + "\(playerId)")!

let task = URLSession.shared.dataTask(with: response) {(data, response, error) in
    guard let data = data else { return }
    print(String(data: data, encoding: .utf8)!)
}

task.resume()

let lcg = URL(string: "http://95.217.177.249/casino/playLcg")!

struct Status : Codable{
    let message: String
    let account: Account
    let realNumber: Int
}

struct Account : Codable{
    let id: String
    let money: Int
    let deletionTime: String
}

func gameRequest(betSum: Int, number: Int) async throws -> Status {
    let url = URL(string: "http://95.217.177.249/casino/playLcg" + "?id=" + "\(playerId)" + "&bet=" + "\(betSum)" + "&number=" + "\(number)")!

    var result = Status(message: "", account: Account(id: "", money: 0, deletionTime: ""), realNumber: 0)

    let (data, _) = try await URLSession.shared.data(from: url)
        print(String(data: data, encoding: .utf8)!)
        let inputJSON = String(data: data, encoding: .utf8)!
        let inputData = inputJSON.data(using: .utf8)!
        let decoder = JSONDecoder()
        let stat = try! decoder.decode(Status.self, from: inputData)
        dump(stat)
        result = stat
    
    task.resume()
    return result
}

Task{
    let bet1 = try await gameRequest(betSum: 1, number: 1)
    var x1 = bet1.realNumber
    //print(bet1.realNumber)
    let bet2 = try await gameRequest(betSum: 1, number: 11)
    var x2 = bet2.realNumber
    //print(bet2.realNumber)
    let bet3 = try await gameRequest(betSum: 1, number: 25)
    var x3 = bet3.realNumber
    //print(bet3.realNumber)
    
    var message = bet1.message
    
    var xn = x3
    
    var a = 0.0
    var c = 0.0
    let m = 4_294_967_296
    
    let forUInt = 2_147_483_648
    
    x1 = x1 + forUInt
    x2 = x2 + forUInt
    x3 = x3 + forUInt
    
//    var str = ""
//    var chars: [Character] = []
//    var valid = true
    
    var i = 0
    
    for k in stride(from: 0, through: 1_000_000, by: 1){
        a = (Double(x2 - x3) + Double(k) * Double(m))/Double((x1 - x2))
//        str = String(a)
//        for elem in str{
//            chars.append(elem)
//        }
//        for elem in chars{
//            while elem != "."{
//                continue
//            }
//            if(elem == "0"){
//                valid = true
//            }
//            else{
//                valid = false
//                continue
//            }
//        }
        
        if(a == a.rounded()){
            i = k
            print(k)
            print(a)
            break
        }
    }
    
    if(i != 0){
        c = Double(x2) + Double(m) * Double(i) - Double(x1) * a
        
        if(c > 0){
            c = Double(Int(c) % m)
        }
        else{
            while(c < Double(m)){
                c = c + Double(m)
            }
        }
        
        //c = Double(Int(c) % m)
        print(c)
        
        while(message == "You lost this time"){
            xn = (xn * Int(a) + Int(c)) % m
            
            
            if(xn > forUInt){
                while(xn > forUInt){
                    xn = xn - forUInt
                }
            }
            else if(xn < -forUInt){
                while(xn < -forUInt){
                    xn = xn + forUInt
                }
            }
            

            
            message = try await gameRequest(betSum: 997, number: xn).message
        }
        print(message)
    }
    print("Finish!!!")
    
}


