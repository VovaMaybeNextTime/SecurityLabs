import UIKit

let url = URL(string: "http://95.217.177.249/casino/createacc")!

let playerId = Int.random(in: 99_999_999...199_999_999)

var response = URL(string: "http://95.217.177.249/casino/createacc" + "?id=" + "\(playerId)")!

let task = URLSession.shared.dataTask(with: response) {(data, response, error) in
    guard let data = data else { return }
    print(String(data: data, encoding: .utf8)!)
}

task.resume()

let lcg = URL(string: "http://95.217.177.249/casino/playLcg")!

struct Status : Codable{
    let message: String
    let account: Account
    let realNumber: Int
}

struct Account : Codable{
    let id: String
    let money: Int
    let deletionTime: String
}

func gameRequest(betSum: Int, number: Int) async throws -> Status {
    let url = URL(string: "http://95.217.177.249/casino/playLcg" + "?id=" + "\(playerId)" + "&bet=" + "\(betSum)" + "&number=" + "\(number)")!

    var result = Status(message: "", account: Account(id: "", money: 0, deletionTime: ""), realNumber: 0)

    let (data, _) = try await URLSession.shared.data(from: url)
        print(String(data: data, encoding: .utf8)!)
        let inputJSON = String(data: data, encoding: .utf8)!
        let inputData = inputJSON.data(using: .utf8)!
        let decoder = JSONDecoder()
        let stat = try! decoder.decode(Status.self, from: inputData)
        dump(stat)
        result = stat
    
    task.resume()
    return result
}

Task{
    let bet1 = try await gameRequest(betSum: 1, number: 1)
    var x1 = bet1.realNumber
    //print(bet1.realNumber)
    let bet2 = try await gameRequest(betSum: 1, number: 11)
    var x2 = bet2.realNumber
    //print(bet2.realNumber)
    let bet3 = try await gameRequest(betSum: 1, number: 25)
    var x3 = bet3.realNumber
    //print(bet3.realNumber)
    
    var message = bet1.message
    
    
    var a = 0.0
    var c = 0.0
    let m = 4_294_967_296
    
    let forUInt = 2_147_483_648
    
    while(x1 < 0 || x1 > forUInt){
        if(x1 < 0){
            x1 = x1 + forUInt
        }
        else{
            x1 = x1 - forUInt
        }
    }
    while(x2 < 0 || x2 > forUInt){
        if(x2 < 0){
            x2 = x2 + forUInt
        }
        else{
            x2 = x2 - forUInt
        }
    }
    while(x3 < 0 || x3 > forUInt){
        if(x3 < 0){
            x3 = x3 + forUInt
        }
        else{
            x3 = x3 - forUInt
        }
    }
    
    var xn = x3
    
//    if(x1 < 0 || x1 > ){
//        x1 = x1 + forUInt
//    }
//    if(x2 < 0){
//        x2 = x2 + forUInt
//    }
//    if(x3 < 0){
//        x3 = x3 + forUInt
//    }
    
//    x1 = x1 + forUInt
//    x2 = x2 + forUInt
//    x3 = x3 + forUInt
    
//    var str = ""
//    var chars: [Character] = []
//    var valid = true
    
    var i = 0
    
    for k in stride(from: -1_000_000, through: 1_000_000, by: 1){
        a = (Double(x2 - x3) + Double(k) * Double(m))/Double((x1 - x2))
//        str = String(a)
//        for elem in str{
//            chars.append(elem)
//        }
//        for elem in chars{
//            while elem != "."{
//                continue
//            }
//            if(elem == "0"){
//                valid = true
//            }
//            else{
//                valid = false
//                continue
//            }
//        }
        
        if(a == a.rounded()){
            i = k
            print("i = ", k)
            print("a = ", a)
            break
        }
    }
    
    if(i != 0){
        c = Double(x2) + Double(m) * Double(i) - Double(x1) * a
        print("c before norm: ", c)
        
//        if(c > 0){
//            c = Double(Int(c) % m)
//        }
//        else{
//            while(c < Double(m)){
//                c = c + Double(forUInt)
//            }
//        }
        while(c < 0 || c > Double(m)){
            if(c > 0){
                c = c - Double(forUInt)
            }
            else{
                c = c + Double(forUInt)
            }
        }
        
        //c = Double(Int(c) % m)
        print("c after norm: ", c)
        
        while(message == "You lost this time"){
            xn = (xn * Int(a) + Int(c)) % m
            
            
            if(xn > forUInt){
                while(xn > forUInt){
                    xn = xn - forUInt
                }
            }
            else if(xn < -forUInt){
                while(xn < -forUInt){
                    xn = xn + forUInt
                }
            }
            

            
            message = try await gameRequest(betSum: 997, number: xn).message
        }
        print(message)
    }
    print("Finish!!!")
    
}


